rosrun virtual_maize_field generate_world.py \
--row_length 3.5 \
--rows_left 0 \
--rows_right 7 \
--row_segments straight \
--hole_prob 0.04 \
--hole_size_max 7 \
--ground_resolution 0.1
